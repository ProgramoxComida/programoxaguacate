<?php 
    require("snippets/bd.php");
 
    header("content-type: application/json");

    if (mysqli_connect_errno($mysqli)) {
        echo "Fallo al conectar a MySQL: " . mysqli_connect_error();
    }

    $getProductores ="";

    if( isset($_POST["nProductor"]) )
    {
        $getProductores = "SELECT * FROM `Productores` WHERE Telefono='".$_POST["nProductor"]."'";
    }
    else {
        if( isset($_POST["idProductor"]) )
        {
            $getProductores = "SELECT * FROM `Productores` WHERE idProductor='".$_POST["idProductor"]."'";    
        }
        else {
            $getProductores = "SELECT * FROM `Productores` WHERE 1";        
        }
    }

    if ($resultado = mysqli_query($conexion, $getProductores )) {

        $arreglo = array();
        while ($row = mysqli_fetch_assoc($resultado)) {
            array_push($arreglo,$row);
   
        }
        mysqli_free_result($resultado);

        if( !empty($arreglo) )
            echo json_encode($arreglo);
        else {
            $res = array("error" => "No se encontraron Resultados");
            echo json_encode($res);
        }
    }
?>