<?php

require("snippets/bd.php");

if (mysqli_connect_errno($mysqli)) {
    echo "Fallo al conectar a MySQL: " . mysqli_connect_error();
}
if( isset($_POST["Nombre"]) && isset($_POST["Telefono"]) && isset($_POST["Ubicacion"]) )
{
    $addProductor = "INSERT INTO `Productores`(`Nombre`, `Telefono`, `Ubicacion`) ".
    "VALUES ("
    ."'".$_POST["Nombre"]."',"
    ."'".$_POST["Telefono"]."',"
    ."'".$_POST["Ubicacion"]."')";

    if ($resultado = mysqli_query($conexion, $addProductor )) {
        $res = array("exito" => "Productor agregado");
        echo json_encode($res);        
    }
    else {
        $res = array("error" => "Error al agregar");
        echo json_encode($res);    
    }
}
else
{
    $res = array("error" => "Informacion Incompleta");
    echo json_encode($res);
}       
?>