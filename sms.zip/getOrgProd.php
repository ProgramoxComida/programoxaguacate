<?php 
    require("snippets/bd.php");
 
    header("content-type: application/json");

    if (mysqli_connect_errno($mysqli)) {
        echo "Fallo al conectar a MySQL: " . mysqli_connect_error();
    }

    $query ="";

    if( isset($_POST["idOrganizacion"]) )
    {
        
        $query = "SELECT a.`Productores_idProductor` as 'idProductor' , b.`Nombre`,b.`Telefono`,b.`Ubicacion`"
                 ."FROM `Organizaciones_has_Productores` as a " 
                 ."INNER JOIN `Productores` as b "
                 ."ON a.`Productores_idProductor` = b.`idProductor`"
                 ."WHERE a.`Organizaciones_idOrganizacion` = ".$_POST["idOrganizacion"];
    }
    else {
        if( isset($_POST["idProductor"]) )
        {
            $query = "SELECT a.`Organizaciones_idOrganizacion` as idOrganizacion, b.`Nombre`,b.`Telefono`,b.`Ubicacion`"
                    ."FROM `Organizaciones_has_Productores` as a " 
                    ."INNER JOIN `Organizaciones` as b "
                    ."ON a.`Organizaciones_idOrganizacion` = b.`idOrganizacion`"
                    ."WHERE a.`Productores_idProductor` = ".$_POST["idProductor"];    
        }
        else {
            $res = array("error" => "Informacion Incompleta");
            echo json_encode($res);
            exit();
        }
    }

    if ($resultado = mysqli_query($conexion, $query )) {

        $arreglo = array();
        while ($row = mysqli_fetch_assoc($resultado)) {
            array_push($arreglo,$row);

        }

        mysqli_free_result($resultado);
        
        if( !empty($arreglo) ){
            echo json_encode($arreglo);
        }
        else {
            $res = array("error" => "No se encontraron Resultados");
            echo json_encode($res);
        }
    } 
    else {
        $res = array("error" => mysqli_error($conexion),"query" => $query);
	    echo json_encode($res);
	} 
    
?>