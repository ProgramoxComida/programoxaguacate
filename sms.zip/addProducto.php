<?php

require("snippets/bd.php");

if (mysqli_connect_errno($mysqli)) {
    echo "Fallo al conectar a MySQL: " . mysqli_connect_error();
}
if( isset($_POST["Nombre"]) )
{
    $addProductor = "INSERT INTO `Productos`(`Nombre`) ".
    "VALUES ("
    ."'".$_POST["Nombre"]."')";

    if ($resultado = mysqli_query($conexion, $addProductor )) {
        $res = array("exito" => "Producto agregado");
        echo json_encode($res);        
    }
    else {
        $res = array("error" => "Error al agregar");
        echo json_encode($res);    
    }
}
else
{
    $res = array("error" => "Informacion Incompleta");
    echo json_encode($res);
}       
?>