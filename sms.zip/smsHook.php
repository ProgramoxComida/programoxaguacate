<?php

require("snippets/bd.php");

header("content-type: text/xml");
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";

if (mysqli_connect_errno($mysqli)) {
    echo "Fallo al conectar a MySQL: " . mysqli_connect_error();
}
if( isset($_POST["From"]) && isset($_POST["Body"]) ) //Si se envio el mensaje
{
    $saveMSG = "INSERT INTO `RegistroMensajes`(`From`, `Body`) VALUES ("
          ."'".$_POST["From"]."',"
          ."'".$_POST["Body"]."')";

    if ($resultado = mysqli_query($conexion, $saveMSG )) {
        $body = $_POST["Body"];
        $from = $_POST["From"];

        $regexp ="/[\+\#\*]|\d{1,}|[^\-]+/";

        preg_match_all($regexp ,$body,$procesado);

        switch ($procesado[0][0]) {
            case "+": //Agregar producto
                $getIDP = "SELECT `idProductor`,`Nombre` FROM `Productores` WHERE `Telefono`='".$from."'";
                if ($resultado = mysqli_query($conexion, $getIDP )) {

                $row = mysqli_fetch_assoc($resultado);
                mysqli_free_result($resultado);
                
                if($row["idProductor"]!="")
                {
                    $addStock = "INSERT INTO `Productos_has_Productores`(`Productos_idProducto`, `Productores_idProductor`, `cantidad`) VALUES ("
                                ."'".$procesado[0][3]."',"
                                ."'".$row["idProductor"]."',"
                                ."'".$procesado[0][1]."') "
                                ."ON DUPLICATE KEY UPDATE "
                                ."`cantidad` =  "
                                ."'".$procesado[0][1]."'";

                    if ($resultado = mysqli_query($conexion, $addStock )) {
                        $res = "Asignado ".$procesado[0][1]." de producto ".$procesado[0][3]." a Productor ".$row["Nombre"];      
                    }
                    else {
                        $res = "No agregado, Intentelo mas tarde";   
                    }
                    
                }
                else {
                    $res ="No estas registrado";
                }
                
            }
                break;
        case "*":
            $getStock = "SELECT a.`Productos_idProducto` as idProducto, b.`Nombre` as Nombre,SUM(`cantidad`) as total " 
                        ."FROM `Productos_has_Productores` as a "
                        ."INNER JOIN `Productos` as b "
                        ."ON a.`Productos_idProducto` = b.`idProducto` "
                        ."WHERE a.`Productos_idProducto` = "
                        ."'".$procesado[0][1]."' "
                        ."GROUP BY (`Productos_idProducto`) ";

                        
            
            if ($resultado = mysqli_query($conexion, $getStock )) {
                    $row = mysqli_fetch_assoc($resultado);

                    $cant = intval($procesado[0][2]);
                    $disp = intval($row["total"]);

                    if($disp >= $cant )
                    {
                        $res = "Contacte a su proveedor, Hay suficiente producto";    
                    }
                    else {
                        $res = "No hay suficiente producto";
                    }      
            }
            else {
                    $res = "No se encontro el producto";   
            }
            mysqli_free_result($resultado);
            break;
        case "#": #Get Inventario de un producto
            $getStock = "SELECT a.`Productos_idProducto` as idProducto, b.`Nombre` as Nombre,SUM(`cantidad`) as total " 
                        ."FROM `Productos_has_Productores` as a "
                        ."INNER JOIN `Productos` as b "
                        ."ON a.`Productos_idProducto` = b.`idProducto` "
                        ."WHERE a.`Productos_idProducto` = "
                        ."'".$procesado[0][1]."' "
                        ."GROUP BY (`Productos_idProducto`) ";

                        
            
            if ($resultado = mysqli_query($conexion, $getStock )) {
                    $row = mysqli_fetch_assoc($resultado);
                    $res = "Hay ".$row["total"]." de ".$row["Nombre"];      
            }
            else {
                    $res = "No se encontro el producto";   
            }
            mysqli_free_result($resultado);
            break;
        default:
            $res="Mensaje Invalido ";
            break;
        }
    }
    else 
    {
        $res = "tenemos problemas con la plataforma Intentelo Mas tarde";  
    }
}
else {
    $res = "Error de peticion";
} 
?>
  
<Response>
    <Message><?php echo $res ?></Message>
</Response>   

