<?php
    $host = "XXXXX";
    $user = "XXXXX";
    $pass = "XXXXX";
    $bd = "XXXXX";
    $conexion = mysqli_connect($host,$user,$pass,$bd);
?>