<?php

require("snippets/bd.php");

if (mysqli_connect_errno($mysqli)) {
    echo "Fallo al conectar a MySQL: " . mysqli_connect_error();
}
if( isset($_POST["idOrganizacion"]) && isset($_POST["idProductor"]) )
{
    $addProductor = "INSERT INTO `Organizaciones_has_Productores`(`Organizaciones_idOrganizacion`, `Productores_idProductor`) VALUES ("
                    ."'".$_POST["idOrganizacion"]."',"
                    ."'".$_POST["idProductor"]."')";

    if ($resultado = mysqli_query($conexion, $addProductor )) {
        $res = array("exito" => "Relacion establecida");
        echo json_encode($res);        
    }
    else {
        $res = array("error" => "Error al agregar");
        echo json_encode($res);    
    }
}
else
{
    $res = array("error" => "Informacion Incompleta");
    echo json_encode($res);
}       
?>